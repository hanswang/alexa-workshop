var config = {

    cognitoIdentityPoolId : "REPLACE_WITH_COGNITO_IDENTITY_POOL_ID",
    ddbTableName : "{{cookiecutter.dynamodb_tablename}}",
    region : "us-east-1"
}

