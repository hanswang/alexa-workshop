// Set constraints for the video stream
var constraints = { video: { facingMode: "user" }, audio: false };
var cameraStream = null;
AWS.config.region = config.region;
var rekognition = null;

// Define constants
const cameraView = document.querySelector("#camera--view"),
    cameraOutput = document.querySelector("#camera--output"),
    cameraSensor = document.querySelector("#camera--sensor"),
    cameraTrigger = document.querySelector("#camera--trigger");

// Access the device camera and stream to cameraView
function cameraStart() {

    if ( config.cognitoIdentityPoolId == "REPLACE_WITH_COGNITO_IDENTITY_POOL_ID" )
    {
        window.location.href = "initial.html";
    }
    else
    {
        navigator.mediaDevices
            .getUserMedia(constraints)
            .then(function(stream) {
                cameraStream = stream.getTracks()[0];
                cameraView.srcObject = stream;

                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: config.cognitoIdentityPoolId
                });
                
                rekognition = new AWS.Rekognition();      
            
            })
            .catch(function(error) {
                console.error("An error has occurred -> ", error);
            });
    }
}

cameraTrigger.onclick = function() {
    cameraSensor.width = cameraView.videoWidth;
    cameraSensor.height = cameraView.videoHeight;
    cameraSensor.getContext("2d").drawImage(cameraView, 0, 0, 400, 300);

    var imageBlob = dataURItoBlob(cameraSensor.toDataURL());
    
    cameraSensor.getContext("2d").drawImage(cameraView, 0, 0);
    cameraOutput.src = cameraSensor.toDataURL();
    cameraOutput.classList.add("objects-capture");
    
    $("#label-results").css('visibility', 'visible');
    $("#label-results").empty();
    $("#label-results").append('<span style="font-size: 20px;" class="label label-default"><span class="rekLabel">Processing - sending ' + imageBlob.length + ' bytes...</span></span><br/><br/>');

    var params = {
        Image: {
         Bytes: imageBlob
        }, 
        MaxLabels: 10, 
        MinConfidence: 90
    };

    rekognition.detectLabels(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else
        {
            $("#label-results").empty();
            var labelTemplate = '<span style="font-size: 20px;" class="label label-success"><span class="rekLabel"></span> <span class="badge"><span class="rekScore"></span>%</span></span><br/><br/>';

                $.each(data.Labels, function( index, value ) {

                    addDetectedItemToDynamoDB(value.Name);

                    var LabelToAdd = $(labelTemplate);
                    $(LabelToAdd).find(".rekLabel").text(value.Name);
                    $(LabelToAdd).find(".rekScore").text(Math.floor(value.Confidence));
                    $("#label-results").append(LabelToAdd);
            });   
        }
    });

};

function addDetectedItemToDynamoDB(objectLabel)
{
    var updateRequest =
    {
        "TableName": config.ddbTableName,
        "Key":
        {
            "objectLabel": { "S": objectLabel },
        },
        ExpressionAttributeNames: {},
        ExpressionAttributeValues: {},
        UpdateExpression: "",
        ReturnValues: "ALL_NEW"
    }

    addExpressionForDDBUpdate(updateRequest, "lastDetected", ""+new Date().getTime(), "N");
    addIncrementForDDBUpdate(updateRequest);

    //
    // Update DynamoDB
    //
    console.log(updateRequest);

    new AWS.DynamoDB().updateItem(
        updateRequest,
        function (err, data) {
            if (err != null) {
                console.log(JSON.stringify(err));
            }
            else {
                console.log(data);
            }
        });
    
}

function dataURItoBlob(dataURI) {
    var binary = atob(dataURI.split(',')[1]);
    var array = [];
    for(var i = 0; i < binary.length; i++) {
        array.push(binary.charCodeAt(i));
    }
    return new Uint8Array(array);
}

// Start the video stream when the window loads
window.addEventListener("load", cameraStart, false);

