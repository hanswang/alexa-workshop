/**
 * Utilities
 */
var lockForm = function(form, lock) {
    form.find(':input, button').attr('disabled', lock);
};

var clearForm = function(form) {
    form.find('input').val('');
};

var updateTextArea = function(textArea, newValue) {
    textArea.val(newValue);
    textArea.attr('rows', textArea.val().split("\n").length);
}

function dataURItoBlob(dataURI) {
  var binary = atob(dataURI.split(',')[1]);
  var array = [];
  for(var i = 0; i < binary.length; i++) {
      array.push(binary.charCodeAt(i));
  }
  return new Uint8Array(array);
}

function addExpressionForDDBUpdate(updateRequest, columnName, paramValue, attributeType)
{
    updateRequest.ExpressionAttributeNames["#"+columnName]   = columnName;

    updateRequest.ExpressionAttributeValues[":"+columnName]  = {};

    if ( attributeType == "B" )
    {
        // Coerce bool to int
        attributeType = "N";
        paramValue    = (paramValue ? "1" : "0");
    }

    updateRequest.ExpressionAttributeValues[":"+columnName][attributeType] = paramValue;

    if ( updateRequest.UpdateExpression.length > 0 )
    {
        updateRequest.UpdateExpression += ", ";
    }
    else
    {
        updateRequest.UpdateExpression = "SET ";
    }

    updateRequest.UpdateExpression += " #"+columnName + " = :" + columnName;

}

function addIncrementForDDBUpdate(updateRequest)
{
    updateRequest.UpdateExpression += " ADD detectionCount :detectionCount";

    updateRequest.ExpressionAttributeValues[":detectionCount"]  = {};
    updateRequest.ExpressionAttributeValues[":detectionCount"]["N"] = "1";
}

var SECOND_MILLIS = 1000;
var MINUTE_MILLIS = 60 * SECOND_MILLIS;
var HOUR_MILLIS = 60 * MINUTE_MILLIS;
var DAY_MILLIS = 24 * HOUR_MILLIS;

function getRelativeTime(now, time)
{
  if (time < 1000000000000)
  {
    // if timestamp given in seconds, convert to millis
    time *= 1000;
  }

  if (time > now || time <= 0)
  {
    return {"words": "Just now", "ageLabelType":"success"};
  }

  // TODO: localize
  var diff = now - time;
  if (diff < MINUTE_MILLIS)
  {
    return {"words": "Just now", "ageLabelType":"success"};
  }
  else if (diff < 2 * MINUTE_MILLIS)
  {
    return {"words": "A minute ago", "ageLabelType":"info"};
  }
  else if (diff < 5 * MINUTE_MILLIS)
  {
    return {"words": "A few minutes ago", "ageLabelType":"warning"};
  }
  else if (diff < 50 * MINUTE_MILLIS)
  {
    return {"words": Math.round(diff / MINUTE_MILLIS) + " minutes ago", "ageLabelType":"default"};
  }
  else if (diff < 90 * MINUTE_MILLIS)
  {
        return {"words": "an hour ago", "ageLabelType":"default"};
  }
  else if (diff < 24 * HOUR_MILLIS)
  {
        return {"words": Math.round(diff / HOUR_MILLIS) + " hours ago", "ageLabelType":"default"};
  }
  else if (diff < 48 * HOUR_MILLIS)
  {
        return {"words": "yesterday", "ageLabelType":"default"};
  }
  else
  {
        return {"words": Math.round(diff / DAY_MILLIS) + " days ago", "ageLabelType":"danger"};
  }
}
