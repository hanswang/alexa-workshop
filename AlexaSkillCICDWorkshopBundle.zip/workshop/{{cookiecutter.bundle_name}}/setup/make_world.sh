#
# Make World - this stands up the Alexa Skill to the final impl
# Though note that you need to manually change the Permissions Boundary policy!
# Also consider manually turning off the Canary deployment before you check in
#

cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
npm install

cd ~/environment/{{cookiecutter.codestar_projectname}}
git config --global credential.helper '!aws codecommit credential-helper $@'
git config --global credential.UseHttpPath true
git config --global user.name "{{cookiecutter.your_name}}"
git config --global user.email {{cookiecutter.your_email_address}}

cd ~/environment/lab_bundle/setup
aws cloudformation create-stack --stack-name {{cookiecutter.cloudformation_stackname}} --region {{cookiecutter.AWS_region}} --capabilities CAPABILITY_NAMED_IAM --template-body file://object_detector.yml

echo "Waiting for {{cookiecutter.cloudformation_stackname}} stack to be created..."
aws cloudformation wait stack-exists --stack-name {{cookiecutter.cloudformation_stackname}} --region {{cookiecutter.AWS_region}} 
aws cloudformation wait stack-create-complete --stack-name {{cookiecutter.cloudformation_stackname}} --region {{cookiecutter.AWS_region}} 
echo "Continuing..."

randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Bottle\"},\"detectionCount\": {\"N\": \"1\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    
randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Glass\"},\"detectionCount\": {\"N\": \"5\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    
randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Chair\"},\"detectionCount\": {\"N\": \"8\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    


cp ~/environment/lab_bundle/lambda/custom/object_detector_full.js ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/object_detector.js
cp ~/environment/lab_bundle/lambda/custom/en-US.json ~/environment/{{cookiecutter.codestar_projectname}}/interactionModels/custom/en-US.json
cp ~/environment/lab_bundle/lambda/custom/index_full.js ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/index.js
#cp ~/environment/lab_bundle/template_full.js ~/environment/{{cookiecutter.codestar_projectname}}/template.js

cd ~/environment/{{cookiecutter.codestar_projectname}}
git add .
git commit -m "Make world"

echo change the policy document!
echo do a git push!


