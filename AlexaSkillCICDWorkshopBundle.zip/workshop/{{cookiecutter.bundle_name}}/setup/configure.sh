#Get cognito identity pool ide
aws cloudformation describe-stacks --stack-name AlexaCICD --query 'Stacks[].Outputs[?OutputKey==`CognitoIdentityPoolId`].OutputValue' --output text

