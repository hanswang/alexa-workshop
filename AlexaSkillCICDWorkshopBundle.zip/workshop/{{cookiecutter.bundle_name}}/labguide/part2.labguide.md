# Building a real-world Alexa skill with CI/CD integration on AWS

## Part 2 - Hands-on Lab Instructions

Welcome to Part 2 of the Hands-on Lab section of the workshop! Now that you have completed the first part of the lab, you have configured a CI/CD pipeline for a basic 'Hello World' skill that allows you to make code and configuration changes, check them in to source control, and have your changes automatically and safely deployed into your production environment. In this second part, you will make further code and configuration changes to build a real-world skill that integrates with AWS services, making use of object detection through Amazon Rekognition. You will deploy a companion web site to Amazon S3. The site will allow you to hold up objects in front of your laptop's web cam, and have the objects that are detected added into a catalogue which can be queried by the Alexa Skill that you will build. The skill itself allows the user to ask 'what was the most-detected object' or 'what object was detected last'. You are welcome to enhance the skill and back-end implementation to add other features as a learning exercise.

This lab guide takes you step-by-step through the code you need to implement to create the application. Or, if you prefer, you can write the code yourself completely as a challenge, or you can simply run a script to implement the code files automatically and avoid having to write the code yourself.

In this lab, you will make use of the following AWS services in addition to the AWS Developer Tools you used in the first part of the lab:

#### Amazon Rekognition

Amazon Rekognition makes it easy to add image and video analysis to your applications. You just provide an image or video to the Rekognition API, and the service can identify the objects, people, text, scenes, and activities, as well as detect any inappropriate content. Amazon Rekognition also provides highly accurate facial analysis and facial recognition on images and video that you provide. You can detect, analyze, and compare faces for a wide variety of user verification, people counting, and public safety use cases.

#### Amazon DynamoDB

Amazon DynamoDB is a key-value and document database that delivers single-digit millisecond performance at any scale. It's a fully managed, multiregion, multimaster database with built-in security, backup and restore, and in-memory caching for internet-scale applications. DynamoDB can handle more than 10 trillion requests per day and support peaks of more than 20 million requests per second.

#### Amazon S3

Amazon Simple Storage Service (Amazon S3) is an object storage service that offers industry-leading scalability, data availability, security, and performance. This means customers of all sizes and industries can use it to store and protect any amount of data for a range of use cases, such as websites, mobile applications, backup and restore, archive, enterprise applications, IoT devices, and big data analytics. Amazon S3 provides easy-to-use management features so you can organize your data and configure finely-tuned access controls to meet your specific business, organizational, and compliance requirements. Amazon S3 is designed for 99.999999999% (11 9's) of durability, and stores data for millions of applications for companies all around the world.

#### Amazon Cognito

Amazon Cognito lets you add user sign-up, sign-in, and access control to your web and mobile apps quickly and easily. Amazon Cognito scales to millions of users and supports sign-in with social identity providers, such as Facebook, Google, and Amazon, and enterprise identity providers via SAML 2.0. In this lab, we will use the 'anonymous guest' feature of Amazon Cognito to provide credentials to allow the website to write detected object metadata to a Amazon DynamoDB table.

#### AWS IAM

AWS Identity and Access Management (IAM) enables you to manage access to AWS services and resources securely. Using IAM, you can create and manage AWS users and groups, and use permissions to allow and deny their access to AWS resources. 


---

### Task 1: Create and configure resources for the object detector 

---

In this task we will create various AWS resources that will support the object detector skill we are building. We will use AWS CloudFormation to automate the creation of the following resources:

* An Amazon DynamoDB table to store the object detection data
* An Amazon Cognito identity pool to provide scoped, temporary credentials for our web page to communicate securely with AWS resources
* AWS IAM Roles to associate with the authorised and unauthorised user principals required by Amazon Cognito

#### Use AWS CloudFormation to automatically create the required resources

1. In the terminal window of the AWS Cloud9 IDE, `cd` into the `lab_guide/setup` folder using this command:
   ```bash
   cd ~/environment/lab_bundle/setup
   ```

2. Run the following command which uses the *AWS CLI* to process the CloudFormation template stored in `object_detector.yml` and deploys the *template-export.yml* CloudFormation template as a new stack called **{{cookiecutter.project_name.replace(' ', '-')}}**.

    ```bash
    aws cloudformation create-stack --stack-name {{cookiecutter.cloudformation_stackname}} --region {{cookiecutter.AWS_region}} --capabilities CAPABILITY_NAMED_IAM --template-body file://object_detector.yml
    ```

3. Open the AWS CloudFormation Console [using this link](https://{{cookiecutter.AWS_region}}.console.aws.amazon.com/cloudformation/home?region={{cookiecutter.AWS_region}}#/stacks?filter=active) (be sure to open the link in a new tab or window). Check the box next to **{{cookiecutter.project_name.replace(' ', '-')}}** stack and then click the **Resources** tab in the lower part of the console to show the AWS resources that have been created as part of the stack. You will note that an Amazon DynamoDB table has been provisioned, as well as a Cognito Identity Pool and some IAM roles.

#### Populate the Amazon DynamoDB table with test data

4. The CloudFormation template created an Amazon DynamoDB table that we will use to hold the objects that are detected. We need to populate this table with some data that we will use for testing. Run the following commands in the IDE's terminal to add sample data to the table:

    ```bash
    randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
    aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Bottle\"},\"detectionCount\": {\"N\": \"1\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    
    randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
    aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Glass\"},\"detectionCount\": {\"N\": \"5\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    
    randomDate=$(($(($(date "+%s") - $((($RANDOM % 100)*10)))) * 1000));
    aws dynamodb put-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --item "{\"objectLabel\": {\"S\": \"Chair\"},\"detectionCount\": {\"N\": \"8\"},\"lastDetected\": {\"S\": \"$randomDate\"}}";    
    ```

5. Click [this link](https://{{cookiecutter.AWS_region}}.console.aws.amazon.com/dynamodb/home?region={{cookiecutter.AWS_region}}#tables:selected={{cookiecutter.dynamodb_tablename}};tab=items) to browse to the Amazon DynamoDB console and confirm that the **{{cookiecutter.dynamodb_tablename}}** table contains sample data.


---

### Task 2: Update the Alexa skill to implement the basics of our object detector

---

We are now ready to start implementing some of the new functionality we need to make our object detector skill function. In this task, we will add a new Intent to the skill to allow you to ask the skill "what was the most detected object?" and return a response based on the test data we have populated in the Amazon DynamoDB table.

#### Create a new feature branch in the source repository

6. In the terminal panel in the IDE, issue the following commands to create a new feature branch in the git repository:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
    git checkout -b new-feature-object-detection-base
    ```

#### Update the interaction model to replace the *HelloWorldIntent* intent

7. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/en-US.json` in the AWS Cloud9 IDE editor, and find the *HelloWorldIntent* definition. Change the intent name to `MostRecentlyDetectedIntent`, and replace the samples as per below:

    ```json
    {
        "name": "MostRecentlyDetectedIntent",
        "slots": [],
        "samples": [
            "what was the most recently detected object",
            "what object did you see last",
            "what object did you last see"
        ]
    }
    ```
 
#### Update the Lambda function code to handle the MostRecentlyDetectedIntent

8. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` in the AWS Cloud9 IDE editor. Make the following changes:

    * Rename the `HelloWorldIntentHandler` function to `MostRecentlyDetectedIntentHandler`
    * Change the canHandle() condition to check for the intent name `MostRecentlyDetectedIntent`
    * Change the handle(handlerInput) function to call a helper, as per this snippet:

        ```java
        handle(handlerInput) {
            return ObjectDetector.handleRequest_MostRecentlyDetected(handlerInput);
            }
        ```

    * Locate the `exports.handler` declaration at the end of the file. Replace `HelloWorldIntentHandler` with `MostRecentlyDetectedIntentHandler` in the `.addRequestHandlers()` list. The complete call should now look like this:

        ```java
        exports.handler = Alexa.SkillBuilders.custom()
        .addRequestHandlers(
            LaunchRequestHandler,
            MostRecentlyDetectedIntentHandler,
            HelpIntentHandler,
            CancelAndStopIntentHandler,
            SessionEndedRequestHandler,
            IntentReflectorHandler) // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
        .addErrorHandlers(
            ErrorHandler)
        .lambda();
        ```  

    * At the top of the file, in the line after the Alexa SDK is brought in, bring in the base implementation of the Object Detector
    
        ```java
        const Alexa = require('ask-sdk-core');
        const ObjectDetector = require("./object_detector");
        ```

9. Save the file.
10. Create a new file in the `{{cookiecutter.codestar_projectname}}/lambda/custom/` folder (right-click on the folder and choose **New File**). Name the file `object_detector.js`
11. In the new file, paste the following implementation:

    ```javascript
    const AWS = require("aws-sdk");

    //
    // Constructor
    //
    function ObjectDetector()
    {
        return this;
    }

    ObjectDetector.prototype.handleRequest_MostRecentlyDetected = function(handlerInput)
    {

        return handlerInput.responseBuilder
            .speak("Sorry, but the most recently detected object feature is not yet fully implemented!")
            .getResponse();
            
    }

    // export the class
    module.exports = new ObjectDetector();
    ```

12. Save the file.

#### Test the new implementation

We will now test the changes that you've made, by debugging the Lambda function in the AWS Cloud9 IDE, and providing a dummy Alexa request payload. 

13. Double-click the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` to ensure it is open in the editor
14. Set a breakpoint in the `MostRecentlyDetectedIntentHandler` inside the `handle()` function, at the call to `return ObjectDetector.handleRequest_MostRecentlyDetected(handlerInput);`
15. Ensure the local Lambda test panel is visible - if it is not, click the **Run** icon at the top of the IDE
16. In the **Payload** field, paste in the following test payload:

```json
{
	"version": "1.0",
	"request": {
		"type": "IntentRequest",
		"locale": "en-US",
		"intent": {
			"name": "MostRecentlyDetectedIntent",
			"confirmationStatus": "NONE"
		}
	}
}
```

*Note: In this test payload, we are providing only the bare minimum required for the Alexa SDK to route the request to our intent handler. As we have not yet deployed our interaction model changes made above, we can't copy the sample I/O from the Alexa simulator as we did before, because the interaction model in the simulator is still referring to the old model - using that payload would fail to call our handler now we have made changes.*

17. Ensure the **Debug** icon in the Lambda test panel is still selected (that it is green) and click **Run** to start a debug session
18. The debugger should stop at the breakpoint in the `MostRecentlyDetectedIntentHandler` function. Step into the call to `ObjectDetector.handleRequest_MostRecentlyDetected`. The debugger will load the ObjectDetector class and allow you to continue stepping through. Let the code run to completion.
19. If all is well, you should see a response payload that says **Sorry, but the most recently detected object feature is not yet fully implemented!** as per the code in `handleRequest_MostRecentlyDetected`


#### Commit the changes to the repository to trigger a deploy

20. Commit the changes to the repository by issuing the following commands in the IDE's terminal panel:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/
    git add .
    git commit -m "Updated interaction model, implemented new MostRecentlyDetectedIntentHandler"
    git push --set-upstream origin new-feature-object-detection-base
    ```
21. Switch back to the `master` branch and merge the changes from the feature branch by running these commands in the terminal panel:

    ```bash
    git checkout master
    git merge new-feature-object-detection-base
    git push
    ```

    The changes will be merged into the master branch and then pushed into the origin repository in AWS CodeCommit.

22. Pushing changes into the repository will trigger a build/deploy cycle through AWS CodePipeline. Open the AWS CodeStar console [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window) to review the progress of the pipeline.
23. When the deployment is complete, click the **Alexa simulator** link in the *Application endpoints* panel of the AWS CodeStar dashboard to open the Alexa developer console simulator.
24. In the Alexa Simulator, type `ask object detector what was the most recently detected object` and hit the *Return* key on your keyboard.
25. If everything is working as expected, you should see the response *"Sorry, but the most recently detected object feature is not yet fully implemented!"*
26. Try the other two *samples* we defined to check that they trigger the skill's Lambda function as expected. Enter `ask object detector what object did you see last` and `ask object detector what object did you last see` and you should see the same response.

---

### Task 3: Implement the "Most recently detected object" behaviour

---

In this task, you will modify the Lambda implementation for the object detector skill so that it retrieves the most recently detected object. At this stage, we will be using test data that we populated the DynamoDB table with in an earlier step. Later, when we build the object detector web page, we will populate the DynamoDB table with real detection data.

27. In the terminal panel in the IDE, issue the following commands to create a new feature branch in the git repository:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
    git checkout -b new-feature-most-recent-detection
    ```

28. You have **three options** for how you want to complete this task:

- ADVANCED: If you prefer to code the implementation by hand without any assistance, go ahead and implement the `handleRequest_MostRecentlyDetected` function the following way:
    * Wrap a Promise() around a call to a function that scans the DynamoDB table to retrieve all the detections and returns an array of objects. Refer to the schema in the DynamoDB table to define the object shape. For inspiration, [refer to this link in the documentation](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/GettingStarted.NodeJs.04.html#GettingStarted.NodeJs.04.Scan)
    * Implement a function that takes an un-ordered array of these objects, and returns the item with the most-recent `lastDetected` object. Call the function with the results from the previous function call.
    * `resolve` the Promise with suitable text to be spoken, using `handlerInput.responseBuilder`
- NON-DEVELOPER: If you prefer not to code anything, run the following command in the AWS Cloud9 IDE to fast-forward the implementation automatically, and then jump to the next task:

    ```bash
    cp ~/environment/lab_bundle/lambda/custom/object_detector_most_recent.js ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/object_detector.js
    ```

    After you run these scripts, jump to the **Next Task.**


- INTERMEDIATE DEVELOPER: If you prefer to craft this code step by step, with assistance from the lab guide, follow on below. 

#### Step by step - update the ObjectDetector.handleRequest_MostRecentlyDetected function to query the DynamoDB table 

29. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/object_detector.js` in the AWS Cloud9 IDE editor
30. In the `ObjectDetector()` constructor, add a new property called `tableName`:

    ```java
    function ObjectDetector()
    {
        this.tableName = "{{cookiecutter.dynamodb_tablename}}";
        return this;
    }
    ```

31. Define a new function called `GetAllDetectedObjects` with the following implementation:

    ```javascript

    ObjectDetector.prototype.GetAllDetectedObjects = function() 
    {
        return new Promise((resolve, reject) => {
            
            var docClient = new AWS.DynamoDB.DocumentClient();
        
            var params = {
                TableName: this.tableName
            };
        
            var items = [];
            
            var scanExecute = function() 
            {
                docClient.scan(params,function(err,result) 
                {
        
                    if(err) 
                    {
                        reject(err);
                    } 
                    else 
                    {
                        items = items.concat(result.Items);
        
                        console.log("     Read " + result.Count + " items");
                        if(result.LastEvaluatedKey) {
        
                            params.ExclusiveStartKey = result.LastEvaluatedKey;
                            console.log("     Starting next page scan...");
                            scanExecute();
                        } 
                        else 
                        {
                            console.log("End of scanning - retrieved " + items.length + " items in total");
                            resolve(items);
                        }   
                    }
                });
            }
            
            console.log("Starting initial scan...")
            scanExecute();
        });
    };

    ```

    This function uses **scan** to retrieve all values in the table, recursively calling the helper until all records have been retrieved. Since **scan** will retrieve a maximum of 1mb of data in a single call, we need to check the value of the `LastEvaluatedKey` property of the return, and if this value is non-null, we continue to call the **scan** method until it is null, which indicates there are no more records to read.

32. Define a new function called `getMostRecentlyDetectedObject` with the following implementation:

    ```java
    ObjectDetector.prototype.getMostRecentlyDetectedObject = function(objectsDetected) 
    {
        var max = {};
        
        if ( objectsDetected && objectsDetected.length > 0 )
            max = objectsDetected.reduce(function (prev, current) {
                return (prev.lastDetected > current.lastDetected) ? prev : current
            });
        
        return max;
    }

    ```

    This function iterates through a collection of detected objects and returns the object with the most recent (largest) `lastDetected` property value.

33. ***Replace*** the current definition of the function `handleRequest_MostRecentlyDetected` with the following implementation:

    ```java
    ObjectDetector.prototype.handleRequest_MostRecentlyDetected = function(handlerInput)
    {
        return new Promise((resolve) => {
            
            this.GetAllDetectedObjects()
                .then((results) => 
                {
                    if( results.length > 0 )
                    {
                        // Get the most-recently detected object
                        var mostRecentlyDetected = this.getMostRecentlyDetectedObject(results);
                        
                        console.log(`Most recently detected object was ${mostRecentlyDetected.objectLabel}`);
        
                        var timesDectectedWords = mostRecentlyDetected.detectionCount > 1 ? ` ${mostRecentlyDetected.detectionCount} times` : "only once."                
                        var secondsAgo = this.spokenTimeFormat(Math.round( (new Date().getTime() - mostRecentlyDetected.lastDetected) / 1000 ));
                        resolve(
                            handlerInput.responseBuilder
                                .speak(`The most recently detected item was a ${mostRecentlyDetected.objectLabel} and that was ${secondsAgo}  ago. It has been detected a total of ${timesDectectedWords}`)
                                .getResponse()
                        );
                    }
                    else
                    {
                        resolve(
                            handlerInput.responseBuilder
                                .speak("There haven't been any recently detected objects.")
                                .getResponse()
                        );
                    }
                })
                .catch((err) => 
                {
                    console.log(err);
                    
                    resolve(
                        handlerInput.responseBuilder
                            .speak("Oops, something went wrong!")
                            .getResponse()
                    );
                
                });

        });
    }        
    ```

    This function orchestrates retrieving all the detected objects from the DynamoDB table, and then retrieves the most-recently detected object using the `getMostRecentlyDetectedObject` function. It then constructs a speech response using the `responseBuilder`.

34. Define a new function called `spokenTimeFormat` with the following implementation:

    ```java
    ObjectDetector.prototype.spokenTimeFormat = function(time)
    {   
        // Hours, minutes and seconds
        var hrs = ~~(time / 3600);
        var mins = ~~((time % 3600) / 60);
        var secs = ~~time % 60;

        var ret = "";

        if (hrs > 0) {
            ret += hrs + " hour";
            if ( hrs > 1 )
                ret +="s";
        }
        if (mins > 0) {
            if ( hrs > 0 )
                ret += " and ";
            ret += mins + " minutes";
        }

        // only do seconds if hours/mins was set
        if (ret == "") {
            ret += secs + " seconds";
        }
        
        return ret;
    }
    ```

    This function returns a 'human readable' version version of the ticks format we are using to represent the object detection date. This allows Alexa to say the time in a more friendly way.

35. Save the `object_detector.js` file


---

### Task 4: Grant permission for Lambda to scan Amazon DynamoDB

---

As part of the CodeStar template we used to create our CI/CD pipeline, an **IAM role** was created for the Lambda function to execute in the context of. This role grants only enough permission for the sample Lambda function to execute - following the best practice of least privilege, that role does not grant permission for the Lambda function to scan an Amazon DynamoDB table. In this task, you will modify the CloudFormation template that the CodeStar template provided, and add permisison for the Lambda Execution Role to have read-only access to DynamoDB.

##### Update the CloudFormation template that created the Lambda Execution Role

36. Open the file `{{cookiecutter.codestar_projectname}}/lambda/template.yml` in the AWS Cloud9 IDE
37. Locate line 49 in the file. It is the end of the `LambdaExecutionRole` definition, and looks like this:

    ```yml
    - !Sub 'arn:${AWS::Partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'    
    ```

38. Add a new line immediately following this line, to grant access to DynamoDB:

    ```yml
    - !Sub 'arn:${AWS::Partition}:iam::aws:policy/AmazonDynamoDBFullAccess'    
    ```

Notice that this grants full access to DynamoDB for the Lambda function. This may seem too unrestrictive, however access to resources are further constrained by a Permissions Boundary that is applied to the Lambda Execution Role. We will edit this role in the next step.

39. Save the file.

##### Update the Permissions Boundary policy for our project to allow access to our DynamoDB table

40. Open the AWS IAM console to the Permissions Boundary policy that is constraining the IAM roles in our project [using this link](https://console.aws.amazon.com/iam/home?region={{cookiecutter.AWS_region}}#/policies/arn:aws:iam::456368186841:policy/CodeStar_{{cookiecutter.codestar_projectname}}_PermissionsBoundary$jsonEditor) (be sure to open the link in a new tab or window).
41. Click **Edit policy**
42. Click the **JSON** tab
43. Scroll down to line 100 and add the following **new IAM policy statement** to the JSON document as the last item in the existing array - be sure to add a comma after the exisitng last item in the policy to ensure the JSON is valid:

    ```json
    {
        "Sid": "AllowDDBReadOnDetectionsTable",
        "Effect": "Allow",
        "Action": [
            "dynamodb:Scan"
        ],
        "Resource": [
            "arn:aws:dynamodb:us-east-1:*:table/{{cookiecutter.project_name}}-Detections"
        ]
    }
    ```

    This new statement grants permission to perform a Scan operation on the DynamoDB table used in our project.

44. Click **Review Policy**
45. Click **Save Changes**

---

### Task 5: Test and deploy the implementation of the Most Recently Detected Object behaviour

---


#### Test the code changes

Let's now test the changes that you've made, by debugging the Lambda function in the AWS Cloud9 IDE, and providing a dummy Alexa request payload as we did in an earlier task.

46. Double-click the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` to ensure it is open in the editor
47. Set a breakpoint in the `MostRecentlyDetectedIntentHandler` inside the `handle()` function, at the call to `return ObjectDetector.handleRequest_MostRecentlyDetected(handlerInput);`. The breakpoint may still be enabled from earlier.
48. Ensure the local Lambda test panel is visible - if it is not, click the **Run** icon at the top of the IDE
49. In the **Payload** field, paste in the following test payload:

```json
{
	"version": "1.0",
	"request": {
		"type": "IntentRequest",
		"locale": "en-US",
		"intent": {
			"name": "MostRecentlyDetectedIntent",
			"confirmationStatus": "NONE"
		}
	}
}
```

50. Click the **Run** icon and step through the code when it hits the breakpoint. Inspect the logic in the function and let it run to completion. If all is well, you should see a message such as *The most recently detected item was a Chair and that was x hours and x minutes  ago. It has been detected a total of 8 times*

#### Commit and push all changes to the source repository

51. Commit the changes to the repository by issuing the following commands in the IDE's terminal panel:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}
    git add .
    git commit -m "Implementation of the most-recently detected object behaviour"
    git push --set-upstream origin new-feature-most-recent-detection
    ```
52. Switch back to the `master` branch and merge the changes from the feature branch by running these commands in the terminal panel:

    ```bash
    git checkout master
    git merge new-feature-most-recent-detection
    git push
    ```

    The changes will be merged into the master branch and then pushed into the origin repository in AWS CodeCommit.

53. Open the AWS CodeStar dashboard [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window) and monitor the CI/CD pipeline deployment of the changes you have made.
54. Once the deployment is complete, move to the next task to test the deployed skill.


#### Test the newly deployed Alexa skill implementation

55. Open the AWS CodeStar dashboard [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window).
56. In the *Application endpoints* panel, click **Alexa Simulator** to open the Alexa developer console simulator.
57. In the Alexa Simulator, type `ask object detector what object did you see last` and hit the *Return* key on your keyboard.
58. If all is well, you should see a response such as:

    ```text
    The most recently detected item was a Chair and that was 35 minutes ago. It has been detected a total of 8 times.
    ````


---

### Task 6: Implement the "Least detected object" and "Most detected object" behaviours

---

In this task, you will modify the Lambda implementation and the Alexa skill interaction model for the object detector skill so that it now supports asking what the most and least detected objects are. At this stage, we will be using test data that we populated the DynamoDB table with in an earlier step. Later, when we build the object detector web page, we will populate the DynamoDB table with real detection data.

59. In the terminal panel in the IDE, issue the following commands to create a new feature branch in the git repository:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
    git checkout -b new-feature-full-skill-implementation
    ```

60. You have **three options** for how you want to complete this task:

- ADVANCED: If you prefer to code the implementation by hand without any assistance, go ahead and implement the `handleRequest_MostRecentlyDetected` function the following way:
    * Implement a function that takes the un-ordered array of detected objects from the previous task implementation of `GetAllDetectedObjects`, and returns the item with the highest count of `detectionCount`. 
    * `resolve` the Promise with suitable text to be spoken, using `handlerInput.responseBuilder`
    * Implement a function that takes the un-ordered array of detected objects from the previous task implementation of `GetAllDetectedObjects`, and returns the item with the lowest count of `detectionCount`. 
    * `resolve` the Promise with suitable text to be spoken, using `handlerInput.responseBuilder`
    * Modify the interaction model for the skill to support the user asking what is the most and least detected objects.
    
- NON-DEVELOPER: If you prefer not to code anything, run the following command in the AWS Cloud9 IDE to fast-forward the implementation automatically, and then jump to the next task:

    ```bash
    cp ~/environment/lab_bundle/lambda/custom/object_detector_full.js ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/object_detector.js
    cp ~/environment/lab_bundle/lambda/custom/en-US.json ~/environment/{{cookiecutter.codestar_projectname}}/interactionModels/custom/en-US.json
    cp ~/environment/lab_bundle/lambda/custom/index_full.js ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/index.js
    ```

    After you run these scripts, jump to the **Next Task.**

- INTERMEDIATE DEVELOPER: If you prefer to craft this code step by step, with assistance from the lab guide, follow on below. 


#### Step by step 

61. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/object_detector.js` in the AWS Cloud9 IDE editor
62. Define a new function called `getLeastDetectedObject` with the following implementation:

    ```java
    ObjectDetector.prototype.getLeastDetectedObject = function(objectsDetected) 
    {
        var min = {};
        
        if ( objectsDetected && objectsDetected.length > 0 )
            min = objectsDetected.reduce(function (prev, current) {
                return (prev.detectionCount < current.detectionCount) ? prev : current
            });
        
        return min;
    }
    ```

63. Define a new function called `getMostDetectedObject` with the following implementation:

    ```java

    ObjectDetector.prototype.getMostDetectedObject = function(objectsDetected) 
    {
        var max = {};
        
        if ( objectsDetected && objectsDetected.length > 0 )
            max = objectsDetected.reduce(function (prev, current) {
                return (prev.detectionCount > current.detectionCount) ? prev : current
            });
        
        return max;
    }
    ```

64. Define a new function called `handleRequest_MostDetected` with the following implementation:

    ```java
    ObjectDetector.prototype.handleRequest_MostDetected = function(handlerInput)
    {
        return new Promise((resolve) => {
            
            this.GetAllDetectedObjects()
                .then((results) => 
                {
                    if( results.length > 0 )
                    {
                        // Get the most-detected object
                        var mostDetected = this.getMostDetectedObject(results);
                        console.log(`Most detected was ${mostDetected.objectLabel}`);
        
                        var timesDectectedWords = mostDetected.detectionCount > 1 ? ` ${mostDetected.detectionCount} times` : "only one time."                
                        resolve(
                            handlerInput.responseBuilder
                                .speak(`The most detected item was ${mostDetected.objectLabel} which was detected ${timesDectectedWords}`)
                                .getResponse()
                        );
                        
                    }
                    else
                    {
                        resolve(
                            handlerInput.responseBuilder
                                .speak("There haven't been any recently detected objects.")
                                .getResponse()
                        );
                    }
                })
                .catch((err) => 
                {
                    console.log(err);
                    
                    resolve(
                        handlerInput.responseBuilder
                            .speak("Oops, something went wrong!")
                            .getResponse()
                    );
                
                });

        });
    }
    ```

65. Define a new function called `handleRequest_LeastDetected` with the following implementation:

    ```java
    ObjectDetector.prototype.handleRequest_LeastDetected = function(handlerInput)
    {
        return new Promise((resolve) => {
            
            this.GetAllDetectedObjects()
                .then((results) => 
                {
                    if( results.length > 0 )
                    {
                        // Get the least-detected object
                        var leastDetected = this.getLeastDetectedObject(results);
                        console.log(`Least detected was ${leastDetected.objectLabel}`);
        
                        var timesDectectedWords = leastDetected.detectionCount > 1 ? `${leastDetected.detectionCount} times` : "only one time."                
                        resolve(
                            handlerInput.responseBuilder
                                .speak(`The least detected item was ${leastDetected.objectLabel} which was detected ${timesDectectedWords}`)
                                .getResponse()
                        );

                    }
                    else
                    {
                        resolve(
                            handlerInput.responseBuilder
                                .speak("There haven't been any recently detected objects.")
                                .getResponse()
                        );
                    }
                })
                .catch((err) => 
                {
                    console.log(err);
                    
                    resolve(
                        handlerInput.responseBuilder
                            .speak("Oops, something went wrong!")
                            .getResponse()
                    );
                
                });

        });
    }
    ```

66. Save the file.    

#### Update the interaction model to support the most and least detected object intents

67. Open the file `{{cookiecutter.codestar_projectname}}/interactionModels/custom/en-US.json` in the AWS Cloud9 IDE editor, and add the following intent definitions to the JSON structure:

    ```json
    {
        "name": "LeastDetectedIntent",
        "slots": [],
        "samples": [
            "what was the least detected object",
            "what object did you see the least"
        ]
    },
    {
        "name": "MostDetectedIntent",
        "slots": [],
        "samples": [
            "what was the most detected object",
            "what object did you see the most"
        ]
    }
    ```
68. Save the file.  

#### Update the Lambda function code to dispatch the new intents

69. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` in the AWS Cloud9 IDE editor
70. Define a new function called `MostDetectedIntentHandler` with the following implementation:

    ```java
    const MostDetectedIntentHandler = {
        canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'MostDetectedIntent';
        },
        handle(handlerInput) {
                return ObjectDetector.handleRequest_MostDetected(handlerInput);
                }
    };
    ```

71. Define a new function called `LeastDetectedIntentHandler` with the following implementation:

    ```java
    const LeastDetectedIntentHandler = {
        canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'LeastDetectedIntent';
        },
        handle(handlerInput) {
                return ObjectDetector.handleRequest_LeastDetected(handlerInput);
                }
    };
    ```

72. Locate the `exports.handler` definition at the end of the file, and change the declaration to include the two new functions `LeastDetectedIntentHandler` and `MostDetectedIntentHandler` as per below:

    ```java
    exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        MostRecentlyDetectedIntentHandler,
        MostDetectedIntentHandler,
        LeastDetectedIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler) // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    .addErrorHandlers(
        ErrorHandler)
    .lambda();
    ```

73. Save the file.

---

### Task 7: Test and deploy the implementation of the Most Detected and Least Detected Objects behaviour

---

#### Test the code changes

Let's now test the changes that you've made, by debugging the Lambda function in the AWS Cloud9 IDE, and providing a dummy Alexa request payload as we did in an earlier task.

74. Double-click the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` to ensure it is open in the editor
75. Set a breakpoint in the `MostDetectedIntentHandler` inside the `handle()` function.
76. Ensure the local Lambda test panel is visible - if it is not, click the **Run** icon at the top of the IDE
77. In the **Payload** field, paste in the following test payload:

```json
{
	"version": "1.0",
	"request": {
		"type": "IntentRequest",
		"locale": "en-US",
		"intent": {
			"name": "MostDetectedIntent",
			"confirmationStatus": "NONE"
		}
	}
}
```

78. Ensure the **Debug** icon in the Lambda test panel is still selected (that it is green) and click **Run** to start a debug session
79. The debugger should stop at the breakpoint and allow you to continue stepping through. Let the code run to completion.
80. If all is well, you should see an appropriate response payload.

81. Set a breakpoint in the `LeastDetectedIntentHandler` inside the `handle()` function.
82. Ensure the local Lambda test panel is visible - if it is not, click the **Run** icon at the top of the IDE
83. In the **Payload** field, paste in the following test payload:

```json
{
	"version": "1.0",
	"request": {
		"type": "IntentRequest",
		"locale": "en-US",
		"intent": {
			"name": "LeastDetectedIntent",
			"confirmationStatus": "NONE"
		}
	}
}
```

84. Ensure the **Debug** icon in the Lambda test panel is still selected (that it is green) and click **Run** to start a debug session
85. The debugger should stop at the breakpoint and allow you to continue stepping through. Let the code run to completion.
86. If all is well, you should see an appropriate response payload.


#### Commit and push all changes to the source repository

87. Commit the changes to the repository by issuing the following commands in the IDE's terminal panel:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}
    git add .
    git commit -m "Implementation of the most-recently detected object behaviour"
    git push --set-upstream origin new-feature-full-skill-implementation
    ```
88. Switch back to the `master` branch and merge the changes from the feature branch by running these commands in the terminal panel:

    ```bash
    git checkout master
    git merge new-feature-full-skill-implementation
    git push
    ```

    The changes will be merged into the master branch and then pushed into the origin repository in AWS CodeCommit.


#### Test the newly deployed Alexa skill implementation

89. Open the AWS CodeStar dashboard [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window).
90. In the *Application endpoints* panel, click **Alexa Simulator** to open the Alexa developer console simulator.
91. In the Alexa Simulator, type `ask object detector what was the least detected object` and hit the *Return* key on your keyboard.
92. If all is well, you should see a response such as:

    ```text
    The least detected item was Chair which was detected 8 times
    ````

93. In the Alexa Simulator, type `ask object detector what was the most detected object` and hit the *Return* key on your keyboard.
94. If all is well, you should see a response such as:

    ```text
    The most detected item was Chair which was detected 8 times
    ````

---

### Task 8: Create a CI/CD pipeline to deliver the object detection website 

---

Now we have a fully operational skill, we need to provide it with real data. In this lab, we will use the web can on your laptop to capture objects, and use Amazon Rekognition to extract objects and update the DynamoDB table.

In this task you will configure a CI/CD pipeline that will automatically deploy the base object detection website we will use to provide input to our Alexa skill. You will manually configure AWS CodePipeline to use an Amazon S3 deployment targeting a bucket that you will use to store the website files. 

You will also set the configuration for the web site so that it can use the Amazon Cognito Identity Pool that was created as part of the CloudFormation stack you provisioned in Task 1. 

### Instructions

#### Create a Amazon S3 bucket to host the object detection website

95. Open the Amazon S3 console [using this link](https://s3.console.aws.amazon.com/s3/home?region={{cookiecutter.AWS_region}}) (be sure to open the link in a new tab or window).
96. Click **Create bucket**
97. For *bucket name* type `{{cookiecutter.website_bucket_name}}`
98. For *region* select **{{cookiecutter.AWS_region_name}}**
99. Click **Create** to create the bucket.
100. Click the link for **{{cookiecutter.website_bucket_name}}** in the list of buckets to drill into the bucket.
101. Click **Permissions**
102. Click **Edit**
103. In the *Manage public access control lists (ACLs) for this bucket* section, unselect **Block new public ACLs and uploading public objects** and **Remove public access granted through public ACLs**
104. Click **Save**
105. In the dialogue that appears, enter `confirm` 
106. Click **Confirm**

#### Create source code repository for the Website

107. We need a repository to provide version control for our website. We will use AWS CodeCommit as our source control system. [Click this link](https://{{cookiecutter.AWS_region}}.console.aws.amazon.com/codesuite/codecommit/repository/create?region={{cookiecutter.AWS_region}}) to browse to the AWS CodeCommit console (be sure to open the link in a new tab or window).
108. For **Repository name** type `{{cookiecutter.project_name.replace(' ', '-')}}-Website`
109. For **RepositoryDescription** type `{{cookiecutter.project_name}} source code repository for the object detection website`
110. Click **Create repository**
111. Your repository will be created, and is now ready to have code checked in. Scroll to the bottom of the CodeCommit window, and note that there are no files in the repository - it has been created empty.

#### Retrieve the Cognito Identity Pool Id from the CloudFormation stack and configure the website

112. In the terminal window of your AWS Cloud9 IDE, execute the following command to retrieve the Cognito Identity Pool Id from the stack you created in Task 1:

```bash
aws cloudformation describe-stacks --stack-name {{cookiecutter.cloudformation_stackname}} --query 'Stacks[].Outputs[?OutputKey==`CognitoIdentityPoolId`].OutputValue' --output text
```

113. Copy the value that is returned into your clipboard. It will look like this `{{cookiecutter.AWS_region}}:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxx`
114. Open the file `lab_bundle/www/config/config.js` in the editor by double-clicking on it in the file exporer in the Cloud9 IDE.
115. The file will have contents as per below. Replace the value for `cognitoIdentityPoolId` with the Cognito Identity Pool Id you have in your clipboard. For example, the file contents changes from this:

```java
var config = {

    cognitoIdentityPoolId : "REPLACE_WITH_COGNITO_IDENTITY_POOL_ID",
    ddbTableName : "AlexaCICDWorkshop-Detections",
    region : "us-east-1"
}
```

to this:

```java
var config = {

    cognitoIdentityPoolId : "{{cookiecutter.AWS_region}}:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxx",
    ddbTableName : "AlexaCICDWorkshop-Detections",
    region : "us-east-1"
}
```

116. Save the file


#### Initialise a new local git repository and push code to the CodeCommit repository

117. Back in the terminal window of your AWS Cloud9 IDE, enter the following commands to configure the credential helper to manage credentials for you automatically based on the IAM role attached to your user account:

```bash
git config --global credential.helper '!aws codecommit credential-helper $@'
git config --global credential.UseHttpPath true
git config --global user.name "{{cookiecutter.your_name}}"
git config --global user.email {{cookiecutter.your_email_address}}
```

118. Initialise a new git repository in the `lab_bundle/www` directory in the Cloud9 IDE, add all the files contained in the directory and then commit and push to the AWS CodeCommit repository using the following commands:

```bash
cd ~/environment/lab_bundle/www/
git init
git add .
git commit -m "Initial commit"
                                                                                                
git remote add origin https://git-codecommit.{{cookiecutter.AWS_region}}.amazonaws.com/v1/repos/{{cookiecutter.project_name.replace(' ', '-')}}-Website
git push -u origin master
```


119. Switch back to the AWS CodeCommit console, and refresh the page to update it - you will now see the files you have aded to the repository and checked in.

#### Create a pipeline to automatically deliver your S3 website

120. Open the AWS CodePipeline Console [using this link](https://{{cookiecutter.AWS_region}}.console.aws.amazon.com/codesuite/codepipeline/pipeline/new?region={{cookiecutter.AWS_region}}#/stacks?filter=active) (be sure to open the link in a new tab or window).

121. In *Step 1: Choose pipeline settings*, for *Pipeline name*, enter `{{cookiecutter.project_name.replace(' ', '-')}}-WebsiteDeployPipeline`
122. For *Artifact store*, select the **Default location** option.
123. Click **Next**
124. In *Step 2: Add source stage*, for *Source provider*, choose **AWS CodeCommit**.
125. In *Repository name*, choose `{{cookiecutter.project_name.replace(' ', '-')}}-Website`
126. In Branch name, choose *master*
127. Leave *Change detection option* set to **Amazon CloudWatch Events** which will use Amazon CloudWatch Events to automatically start the pipleine running when a change is made to the source repository. 
128. Click **Next**.
129. In *Step 3: Add build stage*, choose **Skip build stage**, and then accept the warning message by choosing Skip again.
130. Choose Next.
131. In *Step 4: Add deploy stage*, for *Deploy provider*, choose **Amazon S3**.
132. For *Bucket*, choose `{{cookiecutter.website_bucket_name}}`
133. Select **Extract file before deploy**.
134. Click **Next**.
135. In **Step 5: Review**, review the information, and then choose **Create pipeline**.
136. Your pipeline will be created and will start to run immediately, taking a moment or two to complete.
137. After the new pipeline has run successfully, open the Amazon S3 console and verify that your files appear in your public bucket [using this link](https://s3.console.aws.amazon.com/s3/buckets/{{cookiecutter.website_bucket_name}}/?region={{cookiecutter.AWS_region}}&tab=overview) (be sure to open the link in a new tab or window).
138. Select all of the files in the bucket using the select shortcut checkbox at the top of the list.
139. In the *Actions* menu, click **Make public**
140. Click **Make public**
141. Click the link for the **Index.html** file
142. Open the *Object URL* link in a new window or tab to show the website
143. If the initial deployment and configuration of the website was successful, you will see the object detection web application appear. You should see your web camera output in the browser window. In the next task, you will make use of the web application to detect objects. 

        Keep the web page open for use in the next task.

---

### Task 9: Visit the website to detect objects and test your Alexa Skill end-to-end

---

Congratulations, you have now fully configured the object detector website! In this section, you will use the website to detect objects, and use the Alexa skill to query for detections.


#### Clear the test data from the DynamoDB table

144. Run the following commands in the IDE's terminal to delete the sample from the DynamoDB table:

        ```bash
        aws dynamodb delete-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --key "{\"objectLabel\": {\"S\": \"Bottle\"}}";    
        aws dynamodb delete-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --key "{\"objectLabel\": {\"S\": \"Chair\"}}";    
        aws dynamodb delete-item --region {{cookiecutter.AWS_region}} --table-name {{cookiecutter.dynamodb_tablename}} --key "{\"objectLabel\": {\"S\": \"Glass\"}}";    
        ```

#### Use the web application to start detecting objects

145. In the previous task you opened the `index.html` page in a new browser window, and the web application loaded. 
146. Take an object - such as a coffee cup - and position it so it is prominent in the camera frame.
147. Click the **Detect Obejct** button to snap the image and send it for processing.
148. After a moment or two, you will see the list of objects that the Amazon Rekognition service has extracted from the image you sent. These items will also be added to the Amazon DynamoDB table. [Click this link](https://{{cookiecutter.AWS_region}}.console.aws.amazon.com/dynamodb/home?region={{cookiecutter.AWS_region}}#tables:selected={{cookiecutter.dynamodb_tablename}};tab=items) to browse to the Amazon DynamoDB console and confirm that the **{{cookiecutter.dynamodb_tablename}}** table contains the new detection data.

#### Use the Alexa skill to query for detections

149. Open the AWS CodeStar console [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window) and click the **Alexa simulator** link in the *Application endpoints* panel to open the Alexa developer console simulator.
150. In the Alexa Simulator, type `ask object detector what was the most recently detected object` and hit the *Return* key on your keyboard.
151. If all is well, you should see a response such as:

        ```text
        The most recently detected item was a Coffee Cup and that was 1 minute ago. It has been detected a total of only once.
        ```

152. Try other objects, or multiple detections of the same object. Then try the other two intents we defined in the interaction model - enter `ask object detector what object did you see last` and `ask object detector what object did you last see` and you should see suitable responses.


---

### Task 10: Clean up resources

---

If you are finished this lab, you should clean up the resources used to ensure there are no ongoing charges. Follow the steps below to remove all the resources created in this lab.

153. In the terminal window of your AWS Cloud9 IDE, execute the following command to delete the CloudFormation stack that provisioned the Amazon DynamoDB table and Amazon Cognito Identity Pool:

        ```bash
        aws cloudformation delete-stack --stack-name {{cookiecutter.cloudformation_stackname}} 
        ```

154. Run the following command to delete the Amazon S3 buckets and their contents:

        ```bash
        aws s3 rb s3://{{cookiecutter.website_bucket_name}} --force 
        aws s3 rb s3://awscodestar-{{cookiecutter.codestar_projectname}}-lambda --force 
        aws s3 rb s3://aws-codestar-{{cookiecutter.AWS_region}}-`aws sts get-caller-identity --output text --query 'Account'`-{{cookiecutter.codestar_projectname}}-pipe --force 
        ```

155. Run the following commands to delete the AWS CodePipeline and AWS CodeCommit used for the object detector website project deployment:

        ```bash
        aws codepipeline delete-pipeline --name {{cookiecutter.project_name.replace(' ', '-')}}-WebsiteDeployPipeline
        aws codecommit delete-repository --repository-name {{cookiecutter.project_name.replace(' ', '-')}}-Website
        ```

156. Run the following command to delete the AWS CodeStar project and associated resources:

        ```bash
        aws codestar delete-project --id {{cookiecutter.codestar_projectname}} --delete-stack
        ```




