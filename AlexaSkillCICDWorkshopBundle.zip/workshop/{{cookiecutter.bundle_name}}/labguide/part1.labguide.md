# Building a real-world Alexa skill with CI/CD integration on AWS

## Part 1 - Hands-on Lab Instructions

Welcome to Part 1 of the Hands-on Lab section of the workshop! Now that you have your IDE environment set up, you are ready to start building on the Alexa Skill that has been created for you by AWS CodeStar.

The base bundle has been downloaded and the various components have been customised to your environment based on the answers you provided to the questions during the initialisation process. This lab guide has also been customised to match your environment, making it easy for you to simply cut-and-paste the various commands right from this guide. 

In this lab, you will make use of the following AWS Developer Tools services:

#### AWS CodeCommit

AWS CodeCommit is a fully-managed source control service that makes it easy for companies to host secure and highly scalable private Git repositories. CodeCommit eliminates the need to operate your own source control system or worry about scaling its infrastructure. You can use CodeCommit to securely store anything from source code to binaries, and it works seamlessly with your existing Git tools.

#### AWS CodeBuild

AWS CodeBuild is a fully managed build service that compiles source code, runs tests, and produces software packages that are ready to deploy. With CodeBuild, you don’t need to provision, manage, and scale your own build servers. CodeBuild scales continuously and processes multiple builds concurrently, so your builds are not left waiting in a queue. You can get started quickly by using prepackaged build environments, or you can create custom build environments that use your own build tools. With CodeBuild, you are charged by the minute for the compute resources you use.

#### AWS CodePipeline

AWS CodePipeline is a continuous integration and continuous delivery service for fast and reliable application and infrastructure updates. CodePipeline builds, tests, and deploys your code every time there is a code change, based on the release process models you define. This enables you to rapidly and reliably deliver features and updates. You can easily build out an end-to-end solution by using our pre-built plugins for popular third-party services like GitHub or integrating your own custom plugins into any stage of your release process. With AWS CodePipeline, you only pay for what you use. There are no upfront fees or long-term commitments.

#### AWS CodeDeploy

AWS CodeDeploy is a deployment service that automates application deployments to Amazon EC2 instances or on-premises instances in your own facility. You can deploy a nearly unlimited variety of application content, such as code, web and configuration files, executables, packages, scripts, multimedia files, and so on. AWS CodeDeploy can deploy application content stored in Amazon S3 buckets, GitHub repositories, or Bitbucket repositories. You do not need to make changes to your existing code before you can use AWS CodeDeploy. AWS CodeDeploy makes it easier for you to rapidly release new features, helps you avoid downtime during application deployment, and handles the complexity of updating your applications, without many of the risks associated with error-prone manual deployments.


---

### Task 1: Test the sample Alexa Skill 

---

To begin the lab, we will test the sample Alexa Skill that has been created and automatically deployed for us by the AWS CodeSuite tools, initiated by AWS CodeStar when we created the project.

#### Test the sample Alexa skill in your Alexa developer account

1. Open the AWS CodeStar dashboard [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window).
2. In the *Application endpoints* panel, click **Alexa Simulator** to open the Alexa developer console simulator.
3. Test will be disabled for the skill - enable testing for the skill by choosing *Development* from the drop down list.
4. In the Alexa Simulator, type `tell hello node hello` and hit the *Return* key on your keyboard.
5. After a moment or two, the skill will execute the AWS Lambda function that has been provisioned to provide the compute back-end for your skill. If all is well, you will see the response **Hello World!** in the Alexa simulator and hear Alexa speak if you have audio capabilities.
6. Locate the **Skill I/O** panel, and note the **JSON Input** field. This payload is an example of real data that has been sent to the Lambda function that back-ends the Alexa skill, and we will use this example payload to test the Lambda function directly in the next task. We will come back to this panel in a moment.

---

### Task 2: Debug and locally test the sample Alexa Skill 

---

In this task, we will explore the files and filesystem structure that has been created for us by the AWS CodeStar Alexa Skill template, and also make changes, test and debug the sample code in the AWS Cloud9 IDE.

#### Explore the skill project's filesystem

The AWS Cloud9 template provided the full implementation for a simple 'Hello World' Alexa Skill, which you just tested in the developer portal in the previous task. All the files that make this skill work, and control how the skill is defined, are available on the filesystem structure inside the AWS Cloud9 IDE. The filesystem contains the following files inside the `{{cookiecutter.codestar_projectname}}` folder inside your IDE:

* skill.json - contains the skill manifest that provides Alexa with your skill metadata. [See manifest documentation here](https://developer.amazon.com/docs/smapi/skill-manifest.html)
* `interactionModels` - contains interaction model files in JSON format. [See interaction model documentation here](https://developer.amazon.com/docs/smapi/interaction-model-schema.html).
  * `en-US.json` - contains the interaction model for the en-US locale.
* `lambda` - the parent folder that contains the code of all Lambda functions of this skill.
  * `custom`
    * `package.json` - contains a list of all dependencies.
    * `index.js` - contains the request handling code that will be deployed to AWS Lambda function.
* `buildspec.yml` - used by AWS CodeBuild to package the Lambda function code to be deployed by CodePipeline using CloudFormation.
* `template.yml` - the template with reference to Lambda function code to be deployed by CloudFormation.

#### Install dependencies for the Lambda function

7. Using the built-in terminal in the AWS Cloud9 IDE, `cd` into the folder that contains the Alexa skill Lambda function, and install the dependencies by issuing:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom/    
    npm install
    ```

#### Modify the SAM template to allow AWS Cloud9 to debug the Lambda function

Currently, AWS Cloud9 does not make use of the *CodeUri* property of SAM Serverless Functions when a debugging session is in progress, so we need to make a slight change to the SAM template before we can interactively debug the Lambda function.

8. Open the file `{{cookiecutter.codestar_projectname}}/template.yml` in the AWS Cloud9 IDE
9. Locate line 29 in the file. It is the start of the `Properties` definition for the Lambda function: 

    ```json
    Properties:
      CodeUri: 'lambda/custom'
      Handler: index.handler
    ```

10. Modify the JSON to concatenate the `CodeUri` and `Handler` definitions together. Remove the CodeUri property altogether, so that the resulting JSON looks like this:

    ```json
    Properties:
      Handler: 'lambda/custom/index.handler'
    ```

11. Save the file.

#### Test the Lambda function

12. Open the file `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` by double-clicking on it in the AWS Cloud9 IDE
13. Scroll down to line 24 (note the line numbers in the gutter of the editor) and click to the left of the line number to set a breakpoint.
14. With the `index.js` file open and visible in the editor, click the **Run** icon at the top of the editor window. A test payload panel will appear.
15. Switch back to the Alexa Developer Portal, to the **Skill I/O - JSON Input** panel we located earlier. Copy the entire contents of the JSON Input field into your clipboard (select all the text and use the copy function). 
16. Switch back to the Cloud9 IDE and in the *Payload* section in the side panel, paste in the JSON structure you just copied into your clipboard, ensuring that the JSON you paste completely replaces the existing payload in the panel.
17. Locate the **Run** icon at the top of the panel. Next to the Run icon is the **Debug** icon. It will appear grey - click it to enable debugging. It will turn green.
18. Click the **Run** icon to start executing the function in debug mode
19. After a moment or two, the breakpoint on line 24 will fire, and execution will stop. Take some time to review the various objects in scope, using the debugger panel, or hovering over definitions in the source code. Use the debugging step controls on the Debugger panel that automatically appears to the right of the IDE to step into, through and over statements as you wish, to get a feel for the debuging capabilities of the IDE.
20. Let the code run to completion by clicking the **Play** icon in the Debugger panel on the right. In the **Execution results** panel, you will see output similar to:

    ```json
    {
        "version": "1.0",
        "response": {
            "outputSpeech": {
                "type": "SSML",
                "ssml": "<speak>Hello World!</speak>"
            }
        },
        "userAgent": "ask-node/2.5.1 Node/v8.10.0",
        "sessionAttributes": {}
    }
    ```

21. Take some time to review the entire file, to understand how the code is dispatching to the `HelloWorldIntentHandler` function. We will be changing how this is set up in a later task, as you implement the object detection implementation.

---

### Task 3: Modify the skill's invocation name, public name and behaviour, and re-deploy via CI/CD

---

Now that you have learnt how to set breakpoints and debug the Lambda function in the AWS Cloud9 IDE, you are ready to make a small code change to modify the configuration and behaviour of the skill.

In this task we will make some changes to the skill's interaction model, and use the configured CI/CD pipeline to push the changes out to the Alexa environment. 

#### Configure Git with your details

22. In the terminal window of your AWS Cloud9 IDE, enter the following commands to configure Git with your user details:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}
    git config --global user.name "{{cookiecutter.your_name}}"
    git config --global user.email {{cookiecutter.your_email_address}}
    ```

#### Create a new feature branch in the source repository

23. Still in the terminal panel in the IDE, issue the following commands to create a new feature branch in the git repository:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
    git checkout -b new-feature-universe-response
    ```

#### Add a .gitignore file

24. In the filesystem view in the IDE, right-click on the `{{cookiecutter.codestar_projectname}}` folder and select **New File**
25. Rename the file - type the name `.gitignore` if the file name is in edit mode. If not, you may need to right-click on the **Untitled** file that was created and choose **Rename**
26. Add the following to the file, open in the editor:

    ```text
    # Dependency directories
    node_modules/    
    ```
    
27. Save the file. This will ensure the `node_modules` are not checked into source control when we make changes to the code and push the revision.

#### Change the speechText that is returned from the skill

28. Open `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` by double-clicking on the file in the file explorer in the IDE.
29. On line 24, change the `speechText` that would be returned by the handler:

    ```text
    const speechText = 'Hello Universe!';
    ```

30. Save the file.

#### Change the invocation name for the skill

31. Open the file `{{cookiecutter.codestar_projectname}}/interactionModels/custom/en-US.json` in the AWS Cloud9 IDE editor, and change the value of `invocationName` to `object detector`:

    ```json
    {
    "interactionModel": {
        "languageModel": {
            "invocationName": "object detector",
            "intents": [
                {
                  ...                    
    ```

#### Change the public name and details of the skill

32. Open the file `{{cookiecutter.codestar_projectname}}/skill.json` in the AWS Cloud9 IDE editor, and change the various properties of the `en-US` locale as per below:

    ```json
    "en-US": {
          "summary": "Alexa CI/CD Workshop Object Detector Skill",
          "examplePhrases": [
            "Alexa tell object detector hello"
          ],
          "name": "Object Detector",
          "description": "Alexa CI/CD Workshop Object Detector Skill"
        }
    ```

#### Commit and push all changes to the source repository

33. Commit the changes to the repository by issuing the following commands in the IDE's terminal panel:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}
    git add .
    git commit -m "Updated response text, skill name and public name"
    git push --set-upstream origin new-feature-universe-response
    ```
34. Switch back to the `master` branch and merge the changes from the feature branch by running these commands in the terminal panel:

    ```bash
    git checkout master
    git merge new-feature-universe-response
    git push
    ```

    The changes will be merged into the master branch and then pushed into the origin repository in AWS CodeCommit.

35. Pushing changes into the repository will trigger a build/deploy cycle through AWS CodePipeline. Open the AWS CodeStar console [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window).
36. In the dashboard, note that the CI/CD pipeline has commenced the build and deploy process. You will see the pipeline move from source, to build and then deploy phases. This will take a few minutes because the deployment will be managed through a *blue/green deploy with canary* strategy which will deploy the new Lambda function and send 10 percent of traffic to it, the remaining traffic being sent to the previous Lambda function version. If no errors occur after 5 minutes, then 100% of traffic is sent to the new function version. 

    As the deployment runs through, you can monitor its progress right from the AWS CodeStar dashboard with the pipeline view on the right. When the pipeline reaches the **Deploy** stage, we can drill into the canary deployment directly. Click the **Deploy** icon from the far-left navigation bar in the CodeStar dashboard. The AWS CodeDeploy console will open, and show the deployment groups for the Lambda function that is being deployed.

    In the **Deployment groups** section, click on the **Name** for the deployment group that is showing as **In Progress**.

    The **Deployment Group details** console will appear. Scroll down to the **Deployment group deployment history** section, and click on the name of the **Deployment Id** for the item that is showing as **In progress**.

    The Deployment details will appear. You will see three steps in the **Deployment Status** panel. Once the deployment moves to the **Traffic shifting** phase, this is the **Canary release** part of the process. In the **Traffic shifting progress** panel on the right, you will see that 10% of the traffic is being directed to the new version of the Lambda function. The deployment will remain in this 10%-shifting mode for 5 minutes.

    While in the canary phase, we will test the skill using the *previously* defined invocation `tell hello node hello`. We need to use the *previous* invocation because the skill interaction model is not updated by the pipeline until *after* the canary phase has completed successfully (after 5 minutes).

37. Switch over to the Alexa Simulator again, type `tell hello node hello` and hit the *Return* key on your keyboard. **Repeat this test quite a few times.**
38. You should notice that, 10% of the time, the skill will execute the **new version** of the AWS Lambda function that you changed and you will see the response **Hello Universe!** in the Alexa simulator. 90% of the time however, you will see the previous response of **Hello World!** because only 10% of the invocations will be directed to the new version during the 5-minute canary deployment window. Until the deployment has fully completed (after the 5-minute canary), the **invocation name** and **public name** of the skill will not be updated, which is why you have to use the `tell hello node hello` invocation not the updated `tell object detector hello`. 

    After the 5-minute canary deployment has completed, the interaction model will be updated, and if you use `tell hello node hello` to invoke the skill, you will see the response **Sorry, I'm not sure about that** indicating the invocation did not succeed. From this point, you will need to use `tell object detector hello` to invoke the skill, since we changed the skills invocation name.

---

### Task 4: Change the deployment strategy to speed up deployment while in development

---

As noted in the previous task, the AWS CodeStar Alexa Skill template has configured a canary deployment, which is best practice for staging and production deployments. For development environments however, you may prefer to perform an **all-at-once deployment** instead since there is low risk in a deployment to a development environment, and unlikely you will need to roll back a change - instead you would fix any bugs introduced, and continue to roll-forward. To increase the speed of deployment while we are testing, we will change the deployment strategy to all-at-once.

39. Open the AWS CodeDeploy Applications Console [using this link](https://console.aws.amazon.com/codesuite/codedeploy/applications?region={{cookiecutter.AWS_region}}) (be sure to open the link in a new tab or window).
40. Click the link for the Application named **awscodestar-{{cookiecutter.codestar_projectname}}-lambda-ServerlessDeploymentApplication-XXXXXX**
41. Select the Deployment groups tab
42. Select the Deployment group with the name **awscodestar-{{cookiecutter.codestar_projectname}}-lambda-CustomDefaultFunctionDeploymentGroup-XXXX** 
43. Click **Edit**
44. Scroll down to **Deployment settings** and for **Deployment configuration** choose **CodeDeployLambdaAllAtOnce**
45. Click **Save changes**

---

### OPTIONAL Task 5: Make another change to the source code and deploy via the CI/CD pipeline

---

*Note: This task is optional. If you intend to continue with Part 2 of this lab, you will practice releasing more changes through the pipeline in that section. If you are not intending proceeding with Part 2, you can practice releasing a change and see how the release process is faster without the Canary release, by following along below.*

#### Create a new feature branch in the source repository

46. In the terminal panel in the Cloud9 IDE, issue the following commands to create a new feature branch in the git repository:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}/lambda/custom
    git checkout -b new-feature-myname-response
    ```

#### Change the speechText that is returned from the skill

47. Open `{{cookiecutter.codestar_projectname}}/lambda/custom/index.js` by double-clicking on the file in the file explorer in the IDE.
48. On line 24, change the `speechText` that would be returned by the handler:

    ```text
    const speechText = 'Hello YOUR_NAME!';
    ```

    **Replace** `YOUR_NAME` with your actual name, so that the skill returns `Hello Adam` for example.

49. Save the file.

#### Commit and push all changes to the source repository

50. Commit the changes to the repository by issuing the following commands in the IDE's terminal panel:

    ```bash
    cd ~/environment/{{cookiecutter.codestar_projectname}}
    git add .
    git commit -m "Updated response text, skill name and public name"
    git push --set-upstream origin new-feature-myname-response
    ```
51. Switch back to the `master` branch and merge the changes from the feature branch by running these commands in the terminal panel:

    ```bash
    git checkout master
    git merge new-feature-myname-response
    git push
    ```

    The changes will be merged into the master branch and then pushed into the origin repository in AWS CodeCommit.

52. Pushing changes into the repository will trigger a build/deploy cycle through AWS CodePipeline. Open the AWS CodeStar console [using this link](https://console.aws.amazon.com/codestar/home?region={{cookiecutter.AWS_region}}#/projects/{{cookiecutter.codestar_projectname.replace(' ', '-')}}/dashboard) (be sure to open the link in a new tab or window).
53. In the dashboard, note that the CI/CD pipeline has commenced the build and deploy process. You will see the pipeline move from source, to build and then deploy phases. This will take a minute or two to complete, but this time, the deployment will be executed 'All at once' since we changed the configuration for the deployment strategy in the previous task. 
54. After the deployment, switch over to the Alexa Simulator again, type `tell object detector hello` and hit the *Return* key on your keyboard. You will see that the skill now returns **Hello xxxx** where *xxxx* is your name.
