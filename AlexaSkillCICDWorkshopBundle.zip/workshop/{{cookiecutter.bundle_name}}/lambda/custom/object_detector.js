const AWS = require("aws-sdk");

//
// Constructor
//
function ObjectDetector()
{
    this.tableName = "{{cookiecutter.dynamodb_tablename}}";
    return this;
}

ObjectDetector.prototype.handleRequest_MostRecentlyDetected = function(handlerInput)
{
      return handlerInput.responseBuilder
        .speak("This feature is not yet implemented!")
        .getResponse();
}

// export the class
module.exports = new ObjectDetector();
        