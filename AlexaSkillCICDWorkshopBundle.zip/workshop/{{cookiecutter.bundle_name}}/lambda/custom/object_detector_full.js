const AWS = require("aws-sdk");

//
// Constructor
//
function ObjectDetector()
{
    this.tableName = "{{cookiecutter.dynamodb_tablename}}";
    return this;
}

ObjectDetector.prototype.handleRequest_MostRecentlyDetected = function(handlerInput)
{
    return new Promise((resolve) => {
        
        this.GetAllDetectedObjects()
            .then((results) => 
            {
                if( results.length > 0 )
                {
                    // Get the most-recently detected object
                    var mostRecentlyDetected = this.getMostRecentlyDetectedObject(results);
                    
                    console.log(`Most recently detected object was ${mostRecentlyDetected.objectLabel}`);
    
                    var timesDectectedWords = mostRecentlyDetected.detectionCount > 1 ? ` ${mostRecentlyDetected.detectionCount} times` : "only once."                
                    var secondsAgo = this.spokenTimeFormat(Math.round( (new Date().getTime() - mostRecentlyDetected.lastDetected) / 1000 ));
                    resolve(
                        handlerInput.responseBuilder
                            .speak(`The most recently detected item was a ${mostRecentlyDetected.objectLabel} and that was ${secondsAgo}  ago. It has been detected a total of ${timesDectectedWords}`)
                            .getResponse()
                    );
                }
                else
                {
                    resolve(
                        handlerInput.responseBuilder
                            .speak("There haven't been any recently detected objects.")
                            .getResponse()
                    );
                }
            })
            .catch((err) => 
            {
                console.log(err);
                
                resolve(
                    handlerInput.responseBuilder
                        .speak("Oops, something went wrong!")
                        .getResponse()
                );
               
            });

    });
}

ObjectDetector.prototype.handleRequest_MostDetected = function(handlerInput)
{
    return new Promise((resolve) => {
        
        this.GetAllDetectedObjects()
            .then((results) => 
            {
                if( results.length > 0 )
                {
                    // Get the most-detected object
                    var mostDetected = this.getMostDetectedObject(results);
                    console.log(`Most detected was ${mostDetected.objectLabel}`);
    
                    var timesDectectedWords = mostDetected.detectionCount > 1 ? ` ${mostDetected.detectionCount} times` : "only one time."                
                    resolve(
                        handlerInput.responseBuilder
                            .speak(`The most detected item was ${mostDetected.objectLabel} which was detected ${timesDectectedWords}`)
                            .getResponse()
                    );
                    
                }
                else
                {
                    resolve(
                        handlerInput.responseBuilder
                            .speak("There haven't been any recently detected objects.")
                            .getResponse()
                    );
                }
            })
            .catch((err) => 
            {
                console.log(err);
                
                resolve(
                    handlerInput.responseBuilder
                        .speak("Oops, something went wrong!")
                        .getResponse()
                );
               
            });

    });
}

ObjectDetector.prototype.handleRequest_LeastDetected = function(handlerInput)
{
    return new Promise((resolve) => {
        
        this.GetAllDetectedObjects()
            .then((results) => 
            {
                if( results.length > 0 )
                {
                    // Get the least-detected object
                    var leastDetected = this.getLeastDetectedObject(results);
                    console.log(`Least detected was ${leastDetected.objectLabel}`);
    
                    var timesDectectedWords = leastDetected.detectionCount > 1 ? `${leastDetected.detectionCount} times` : "only one time."                
                    resolve(
                        handlerInput.responseBuilder
                            .speak(`The least detected item was ${leastDetected.objectLabel} which was detected ${timesDectectedWords}`)
                            .getResponse()
                    );

                }
                else
                {
                    resolve(
                        handlerInput.responseBuilder
                            .speak("There haven't been any recently detected objects.")
                            .getResponse()
                    );
                }
            })
            .catch((err) => 
            {
                console.log(err);
                
                resolve(
                    handlerInput.responseBuilder
                        .speak("Oops, something went wrong!")
                        .getResponse()
                );
               
            });

    });
}

ObjectDetector.prototype.GetAllDetectedObjects = function() 
{
    return new Promise((resolve, reject) => {
        
        var docClient = new AWS.DynamoDB.DocumentClient();
     
        var params = {
            TableName: this.tableName
        };
     
        var items = [];
         
        var scanExecute = function() 
        {
            docClient.scan(params,function(err,result) 
            {
     
                if(err) 
                {
                    reject(err);
                } 
                else 
                {
                    items = items.concat(result.Items);
     
                    console.log("     Read " + result.Count + " items");
                    if(result.LastEvaluatedKey) {
     
                        params.ExclusiveStartKey = result.LastEvaluatedKey;
                        console.log("     Starting next page scan...");
                        scanExecute();
                    } 
                    else 
                    {
                        console.log("End of scanning - retrieved " + items.length + " items in total");
                        resolve(items);
                    }   
                }
            });
        }
        
        console.log("Starting initial scan...")
        scanExecute();
    });
};

ObjectDetector.prototype.getLeastDetectedObject = function(objectsDetected) 
{
    var min = {};
    
    if ( objectsDetected && objectsDetected.length > 0 )
        min = objectsDetected.reduce(function (prev, current) {
            return (prev.detectionCount < current.detectionCount) ? prev : current
        });
    
    return min;
}

ObjectDetector.prototype.getMostDetectedObject = function(objectsDetected) 
{
    var max = {};
    
    if ( objectsDetected && objectsDetected.length > 0 )
        max = objectsDetected.reduce(function (prev, current) {
            return (prev.detectionCount > current.detectionCount) ? prev : current
        });
    
    return max;
}

ObjectDetector.prototype.getMostRecentlyDetectedObject = function(objectsDetected) 
{
    var max = {};
    
    if ( objectsDetected && objectsDetected.length > 0 )
        max = objectsDetected.reduce(function (prev, current) {
            return (prev.lastDetected > current.lastDetected) ? prev : current
        });
    
    return max;
}

ObjectDetector.prototype.spokenTimeFormat = function(time)
{   
    // Hours, minutes and seconds
    var hrs = ~~(time / 3600);
    var mins = ~~((time % 3600) / 60);
    var secs = ~~time % 60;

    var ret = "";

    if (hrs > 0) {
        ret += hrs + " hour";
        if ( hrs > 1 )
            ret +="s";
    }
    if (mins > 0) {
        if ( hrs > 0 )
            ret += " and ";
        ret += mins + " minutes";
    }

    // only do seconds if hours/mins was set
    if (ret == "") {
        ret += secs + " seconds";
    }
    
    return ret;
}

// export the class
module.exports = new ObjectDetector();
